export default function AboutPage() {
    return (
      <div style={{ padding: "2rem" }}>
        <h2>About Page</h2>
        <p>This is a simple About page for demonstration purposes.</p>
      </div>
    );
  }
  